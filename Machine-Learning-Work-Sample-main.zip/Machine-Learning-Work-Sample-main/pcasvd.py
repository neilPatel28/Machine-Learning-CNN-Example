import torch
import torchvision
import torchvision.transforms.v2 as transforms
import torch.nn as nn
import torch.optim as optim
from cnn import *
from openpyxl import load_workbook
import time
import datetime

# Data preparation
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

batch_size = 64

trainset = torchvision.datasets.FashionMNIST(root="data", train=True, download=False, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True)

testset = torchvision.datasets.FashionMNIST(root="data", train=False, download=False, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=False)

# Model setup
conv_net = Conv_Net()
criterion = nn.CrossEntropyLoss()
optimizer_cnn = optim.Adam(conv_net.parameters(), lr=0.001)

#--------------------------------------------------------
# Load trained model
conv_net.load_state_dict(torch.load('cnnTucker.pth'))
# change cnn file to match this

# Evaluate test
correct = 0
total = 0
conv_net.eval()
with torch.no_grad():
    for images, labels in testloader:
        outputs = conv_net(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

accuracyTest = correct / total
print(f'Accuracy: {accuracyTest:.4f}')


#-----------------------------------------------------------------------------------------
# in class we have been tested and completed homeworks on SVD, PCA, Grassmann Distance,
# we will now apply it to machine learning problem with the help of our northeastern claude acounts
import numpy as np
import matplotlib.pyplot as plt

conv1_weights = conv_net.conv1.weight.data  # Shape: (32, 1, 3, 3)
conv1_flat = conv1_weights.view(conv1_weights.shape[0], -1).cpu().numpy()

U1, S1, Vt1 = np.linalg.svd(conv1_flat, full_matrices=False)

cumsum1 = np.cumsum(S1) / np.sum(S1)

conv2_weights = conv_net.conv2.weight.data  # Shape: (64, 32, 3, 3)
conv2_flat = conv2_weights.view(conv2_weights.shape[0], -1).cpu().numpy()

U2, S2, Vt2 = np.linalg.svd(conv2_flat, full_matrices=False)


# Calculate cumulative variance
cumsum2 = np.cumsum(S2) / np.sum(S2)

fc1_weights = conv_net.fc1.weight.data.cpu().numpy()

U3, S3, Vt3 = np.linalg.svd(fc1_weights, full_matrices=False)


# Calculate cumulative variance
cumsum3 = np.cumsum(S3) / np.sum(S3)
n_95 = np.argmax(cumsum3 >= 0.95) + 1

fig, axes = plt.subplots(2, 3, figsize=(15, 10))

# Row 1: Singular values
axes[0, 0].plot(S1, 'o-')
axes[0, 0].set_title('Conv1 Singular Values')
axes[0, 0].set_xlabel('Index')
axes[0, 0].set_ylabel('Singular Value')
axes[0, 0].grid(True)

axes[0, 1].plot(S2, 'o-')
axes[0, 1].set_title('Conv2 Singular Values')
axes[0, 1].set_xlabel('Index')
axes[0, 1].set_ylabel('Singular Value')
axes[0, 1].grid(True)

axes[0, 2].plot(S3[:50], 'o-')  # Plot first 50
axes[0, 2].set_title('FC1 Singular Values (first 50)')
axes[0, 2].set_xlabel('Index')
axes[0, 2].set_ylabel('Singular Value')
axes[0, 2].grid(True)

# Row 2: Cumulative variance
axes[1, 0].plot(cumsum1 * 100)
axes[1, 0].axhline(y=95, color='r', linestyle='--', label='95%')
axes[1, 0].set_title('Conv1 Cumulative Variance')
axes[1, 0].set_xlabel('Number of Components')
axes[1, 0].set_ylabel('Variance Explained (%)')
axes[1, 0].legend()
axes[1, 0].grid(True)

axes[1, 1].plot(cumsum2 * 100)
axes[1, 1].axhline(y=95, color='r', linestyle='--', label='95%')
axes[1, 1].set_title('Conv2 Cumulative Variance')
axes[1, 1].set_xlabel('Number of Components')
axes[1, 1].set_ylabel('Variance Explained (%)')
axes[1, 1].legend()
axes[1, 1].grid(True)

axes[1, 2].plot(cumsum3[:100] * 100)  # Plot first 100
axes[1, 2].axhline(y=95, color='r', linestyle='--', label='95%')
axes[1, 2].set_title('FC1 Cumulative Variance (first 100)')
axes[1, 2].set_xlabel('Number of Components')
axes[1, 2].set_ylabel('Variance Explained (%)')
axes[1, 2].legend()
axes[1, 2].grid(True)

plt.tight_layout()
plt.show()


print(f"95% Components - Conv1: {np.argmax(cumsum1>=0.95)+1}/{len(S1)} "
      f"({100*np.argmax(cumsum1>=0.95)/len(S1):.1f}%) | Conv2: {np.argmax(cumsum2>=0.95)+1}/{len(S2)} "
      f"({100*np.argmax(cumsum2>=0.95)/len(S2):.1f}%) | FC1: {np.argmax(cumsum3>=0.95)+1}/{len(S3)} "
      f"({100*np.argmax(cumsum3>=0.95)/len(S3):.1f}%)")











from sklearn.decomposition import PCA

def get_features(model, dataloader, max_batches=None):
    model.eval()
    features = []
    labels_list = []

    with torch.no_grad():
        for batch_idx, (images, labels) in enumerate(dataloader):
            # Forward pass through conv layers
            x = model.relu(model.conv1(images))
            x = model.pool(x)
            x = model.relu(model.conv2(x))
            x = model.pool(x)
            x = x.view(-1, 64 * 7 * 7)
            x = model.relu(model.fc1(x))

            features.append(x.cpu().numpy())
            labels_list.append(labels.cpu().numpy())

    return np.vstack(features), np.hstack(labels_list)


features, labels = get_features(conv_net, testloader, max_batches=50)


# Full PCA to analyze variance
pca_full = PCA()
pca_full.fit(features)

# Calculate components needed
cumsum = np.cumsum(pca_full.explained_variance_ratio_)
n_comp_90 = np.argmax(cumsum >= 0.90) + 1
n_comp_95 = np.argmax(cumsum >= 0.95) + 1

# plot first 2 pca
pca_2d = PCA(n_components=2)
features_2d = pca_2d.fit_transform(features)


# Class names for FashionMNIST
class_names = ['T-shirt', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

fig, axes = plt.subplots(2, 2, figsize=(14, 12))

# Plot 1: 2D PCA scatter (all classes)
scatter = axes[0, 0].scatter(features_2d[:, 0], features_2d[:, 1],
                             c=labels, cmap='tab10', alpha=0.6, s=10)
axes[0, 0].set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0] * 100:.1f}%)')
axes[0, 0].set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1] * 100:.1f}%)')
axes[0, 0].set_title('PCA: 2D Feature Space (All Classes)')
axes[0, 0].grid(True, alpha=0.3)
cbar = plt.colorbar(scatter, ax=axes[0, 0])
cbar.set_label('Class')

# Plot 2: Explained variance per component
axes[0, 1].bar(range(1, 21), pca_full.explained_variance_ratio_[:20])
axes[0, 1].set_xlabel('Principal Component')
axes[0, 1].set_ylabel('Explained Variance Ratio')
axes[0, 1].set_title('Explained Variance per Component (first 20)')
axes[0, 1].grid(True, alpha=0.3)

# Plot 3: Cumulative explained variance
axes[1, 0].plot(cumsum[:50] * 100, linewidth=2)
axes[1, 0].axhline(y=90, color='r', linestyle='--', label='90%', alpha=0.7)
axes[1, 0].set_xlabel('Number of Components')
axes[1, 0].set_ylabel('Cumulative Variance Explained (%)')
axes[1, 0].set_title('Cumulative Explained Variance (first 50)')
axes[1, 0].legend()
axes[1, 0].grid(True, alpha=0.3)

# Plot 4: 2D PCA with class labels (subset of classes for clarity)
selected_classes = [1, 5, 7]  # Trouser, Sandal, Sneaker
for class_idx in selected_classes:
    mask = labels == class_idx
    axes[1, 1].scatter(features_2d[mask, 0], features_2d[mask, 1],
                       label=class_names[class_idx], alpha=0.6, s=20)
axes[1, 1].set_xlabel(f'PC1 ({pca_2d.explained_variance_ratio_[0] * 100:.1f}%)')
axes[1, 1].set_ylabel(f'PC2 ({pca_2d.explained_variance_ratio_[1] * 100:.1f}%)')
axes[1, 1].set_title('PCA: Selected Classes (Trouser, Sandal, Sneaker)')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()

plt.show()


#---------------------------------------------------------------------------------------------
def grassmann_distance_fixed(features_class1, features_class2, n_components=None):
    """
    Compute Grassmann distance between two subspaces
    Handles high-dimensional features properly
    """
    # Limit components to avoid rank issues
    if n_components is None:
        n_components = min(
            features_class1.shape[0] - 1,  # Can't exceed sample count
            features_class2.shape[0] - 1,
            50  # Cap at 50 to avoid numerical issues
        )

    # Use PCA to reduce to meaningful dimensions first
    from sklearn.decomposition import PCA

    # Fit PCA on combined data to get shared basis
    combined = np.vstack([features_class1, features_class2])
    pca = PCA(n_components=n_components)
    pca.fit(combined)

    # Project both classes
    proj1 = pca.transform(features_class1)  # (n_samples1, n_components)
    proj2 = pca.transform(features_class2)  # (n_samples2, n_components)

    # Now compute Grassmann distance in reduced space
    # Transpose because we want column space
    Q1, _ = np.linalg.qr(proj1.T)
    Q2, _ = np.linalg.qr(proj2.T)

    # Keep only valid dimensions
    rank1 = np.linalg.matrix_rank(Q1)
    rank2 = np.linalg.matrix_rank(Q2)
    Q1 = Q1[:, :rank1]
    Q2 = Q2[:, :rank2]

    # Compute SVD
    _, singular_values, _ = np.linalg.svd(Q1.T @ Q2, full_matrices=False)

    # Principal angles
    singular_values = np.clip(singular_values, 0, 1)
    principal_angles = np.arccos(singular_values)

    # Grassmann distance
    grassmann_dist = np.sqrt(np.sum(principal_angles ** 2))

    return grassmann_dist, principal_angles


# Get features for confused classes
shirt_features = features[labels == 6]
tshirt_features = features[labels == 0]
sandal_features = features[labels == 5]
sneaker_features = features[labels == 7]
trouser_features = features[labels == 1]

# Shirt vs T-shirt
dist_st, angles_st = grassmann_distance_fixed(shirt_features, tshirt_features, n_components=20)
print(f"\nShirt vs T-shirt:")
print(f"  Grassmann distance: {dist_st:.4f}")
print(f"  First 5 principal angles (degrees): {np.degrees(angles_st[:5])}")
print(f"  Mean angle: {np.degrees(angles_st.mean()):.2f}°")

# Sandal vs Sneaker
dist_ss, angles_ss = grassmann_distance_fixed(sandal_features, sneaker_features, n_components=20)
print(f"\nSandal vs Sneaker:")
print(f"  Grassmann distance: {dist_ss:.4f}")
print(f"  First 5 principal angles (degrees): {np.degrees(angles_ss[:5])}")
print(f"  Mean angle: {np.degrees(angles_ss.mean()):.2f}°")

print("\n--- Well-Separated Classes ---")

# Trouser vs Shirt
dist_ts, angles_ts = grassmann_distance_fixed(trouser_features, shirt_features, n_components=20)
print(f"\nTrouser vs Shirt:")
print(f"  Grassmann distance: {dist_ts:.4f}")
print(f"  First 5 principal angles (degrees): {np.degrees(angles_ts[:5])}")
print(f"  Mean angle: {np.degrees(angles_ts.mean()):.2f}°")

