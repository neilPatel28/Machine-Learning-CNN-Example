import torch
import torch.nn as nn


class convo2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding=1, rank_ratio=0.5):
        super().__init__()

        # Calculate ranks for each mode
        rank_out = max(1, int(out_channels * rank_ratio))
        rank_in = max(1, int(in_channels * rank_ratio))
        rank_spatial = max(1, int(kernel_size * rank_ratio))

        #Output channel factorization
        self.output_factor = nn.Conv2d(rank_out, out_channels, kernel_size=1, bias=False)

        #Input channel factorization
        self.input_factor = nn.Conv2d(in_channels, rank_in, kernel_size=1, bias=False)

        # Spatial factorization
        self.core_tensor = nn.Conv2d(
            rank_in,
            rank_out,
            kernel_size=kernel_size,
            padding=padding
        )

        self.rank_in = rank_in
        self.rank_out = rank_out
        self.rank_spatial = rank_spatial

    def forward(self, x):
        x = self.input_factor(x)
        x = self.core_tensor(x)
        x = self.output_factor(x)

        return x

    def get_compression_ratio(self):
        # Standard conv parameters
        standard_params = (self.output_factor.out_channels *
                           self.input_factor.in_channels *
                           self.core_tensor.kernel_size[0] *
                           self.core_tensor.kernel_size[1])

        # Tucker decomposed parameters
        tucker_params = (
                self.input_factor.weight.numel() +  # U2
                self.core_tensor.weight.numel() +  # G
                self.output_factor.weight.numel()  # U1
        )

        compression_ratio = standard_params / tucker_params
        return compression_ratio

    @property
    def weight(self):
        return self.core_tensor.weight

