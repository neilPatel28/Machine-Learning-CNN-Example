import torch
import torchvision
import torchvision.transforms.v2 as transforms
import torch.optim as optim
from cnn import *
from openpyxl import load_workbook
import time
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
import seaborn as sns

# Data preparation
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

batch_size = 64
trainTime = 0
params = 0
iterations = 0


trainset = torchvision.datasets.FashionMNIST(root="data", train=True, download=False, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True)

testset = torchvision.datasets.FashionMNIST(root="data", train=False, download=False, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=False)

# Model setup
conv_net = Conv_Net()
criterion = nn.CrossEntropyLoss()
optimizer_cnn = optim.Adam(conv_net.parameters(), lr=0.001)
start_time = time.time()

"""# Training (currently commented out - uncomment to train)
for epoch in range(10):
    running_loss = 0.0
    for inputs, labels in trainloader:
        optimizer_cnn.zero_grad()
        outputs = conv_net(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer_cnn.step()
        running_loss += loss.item()
        iterations += 1

    print(f"Epoch {epoch + 1}, Loss: {running_loss}")

end_time = time.time()
trainTime = end_time - start_time

#torch.save(conv_net.state_dict(), 'cnn.pth')
#torch.save(conv_net.state_dict(), 'cnnTucker.pth')
#torch.save(conv_net.state_dict(), 'cnnF1.pth')
torch.save(conv_net.state_dict(), 'cnnSuper.pth')"""



# Count parameters
total_params = sum(p.numel() for p in conv_net.parameters())
params = sum(p.numel() for p in conv_net.parameters() if p.requires_grad)





#--------------------------------------------------------
# Load trained model
#conv_net.load_state_dict(torch.load('cnn.pth'))
#conv_net.load_state_dict(torch.load('cnnTucker.pth'))
#conv_net.load_state_dict(torch.load('cnnF1.pth'))
#conv_net.load_state_dict(torch.load('cnnSuper.pth'))



# Evaluate train
correct = 0
total = 0
conv_net.eval()
start_time = time.time()
with torch.no_grad():
    for images, labels in trainloader:
        outputs = conv_net(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()


end_time = time.time()
time1 = end_time - start_time
accuracyTrain = correct / total
print(f'Accuracy: {accuracyTrain:.4f}')

# Evaluate test
correct = 0
total = 0
conv_net.eval()
start_time = time.time()
with torch.no_grad():
    for images, labels in testloader:
        outputs = conv_net(images)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()


end_time = time.time()
time2 = end_time - start_time


accuracyTest = correct / total
print(f'Accuracy: {accuracyTest:.4f}')



#--------------------------------------------------
"""# Load  workbook
wb = load_workbook('test.xlsx')
ws = wb.active


col = 5
# Write results
ws.cell(row=2, column=col, value=f"{accuracyTrain:.4f}")

if trainTime != 0:
    ws.cell(row=11, column=col, value=f"{trainTime:.2f}s")

if params != 0:
    ws.cell(row=10, column=col, value=f"{params:,}")
if iterations != 0:
    ws.cell(row=12, column=col, value=f"{iterations:,}")

ws.cell(row=2, column=(col+7), value=f"{accuracyTest:,}")

ws.cell(row=3, column=col, value=f"{time1:,}")
ws.cell(row=3, column=col+7, value=f"{time2:,}")



# Save Excel
wb.save('test.xlsx')"""

#-------------------------------------------------------------
def plot_confusion_matrix(model, dataloader):
    """
    Generate and save confusion matrix for the model

    Args:
        model: Trained neural network
        dataloader: Test data loader
        save_name: Filename to save the plot
    """
    label_names = [
        "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
        "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
    ]

    # Get all predictions
    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for images, labels in dataloader:
            outputs = model(images)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    all_preds = np.array(all_preds)
    all_labels = np.array(all_labels)

    # Create confusion matrix
    cm = confusion_matrix(all_labels, all_preds)

    # Plot
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=label_names, yticklabels=label_names)
    plt.title("Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.tight_layout()


    plt.show()

    return cm

cm = plot_confusion_matrix(conv_net, testloader)
